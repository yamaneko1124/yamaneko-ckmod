#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"

//Target lib here
#define targetLibName OBFUSCATE("libSGF.so")

#include "Includes/Macros.h"
#include "Function/Function.h"

struct My_Patches {
    MemoryPatch
	SpeedReset,
	Speed1,
	Speed2,
	Speed3,
	Speed4,
	Speed5,
	DamageReset,
	Damage1,
	Damage2,
	Damage3,
	SlowReset,
	Slow1,
	Slow2,
	Slow3,
	Slow4;
} hexPatches;

//================================================================================================================================================

//Hook
bool keiryou = false;
bool postscore = false;
bool enemyturn = false;
bool jikkyou = false;
bool ranking = false;
bool backButton = false;
bool friendList = false;
int youkaiDrop = 0;
int youkaiiDrop = 0;
int itemDrop = 0;

bool score = false;
int scoretype = 1;
int scorev = 0;


bool addtime = false;
int timev = 0;

bool onehit = false;
int ty = 1;
float damage = 0;
int bai = 1;
int man = 1;

int marbledamage = 0;
int damagevalue = 0;

float marblespeed = 0;
float speedvalue = 0;

//bool ScoreUpdate;
//int Scorevalve = 0;
//1.keiryou

int (*old_MarbleDamage)(void *instance);
int MarbleDamage(void *instance) {
    if (instance != NULL && marbledamage) {
        return (int) damagevalue;
    }
    return old_MarbleDamage(instance);
}

float (*old_MarbleSpeed)(void *instance);
float MarbleSpeed(void *instance) {
    if (instance != NULL && marblespeed) {
        return (float) 2500;
    }
    return old_MarbleSpeed(instance);
}
bool (*old_Keiryou)(void *instance);
bool Keiryou(void *instance) {
    if (instance != NULL && keiryou) {
        return false;
    }
    return old_Keiryou(instance);
}
//2.postscore
bool (*old_PostScore)(void *instance);
bool PostScore(void *instance) {
    if (instance != NULL && postscore) {
        return true;
    }
    return old_PostScore(instance);
}
//3.enemyturn
float (*old_Enemyturn)(void *instance);
float Enemyturn(void *instance) {
    if (instance != NULL && enemyturn) {
        return 0.0;
    }
    return old_Enemyturn(instance);
}

bool (*old_Jikkyou)(void *instance);
bool Jikkyou(void *instance) {
    if (instance != NULL && jikkyou) {
        return true;
    }
    return old_Jikkyou(instance);
}

bool (*old_Ranking)(void *instance);
bool Ranking(void *instance) {
    if (instance != NULL && ranking) {
        return true;
    }
    return old_Ranking(instance);
}

bool (*old_BackButton)(void *instance);
bool BackButton(void *instance) {
    if (instance != NULL && backButton) {
        return true;
    }
    return old_BackButton(instance);
}

bool (*old_FriendList)(void *instance);
bool FriendList(void *instance) {
    if (instance != NULL && friendList) {
        return true;
    }
    return old_FriendList(instance);
}


int (*old_YoukaiDrop)(void *instance);
int YoukaiDrop(void *instance) {
    if (instance != NULL && youkaiDrop) {
        return 9999999;
    }
    return old_YoukaiDrop(instance);
}

int (*old_YoukaiiDrop)(void *instance);
int YoukaiiDrop(void *instance) {
    if (instance != NULL && youkaiiDrop) {
        return 0;
    }
    return old_YoukaiiDrop(instance);
}  

int (*old_ItemDrop)(void *instance);
int ItemDrop(void *instance) {
    if (instance != NULL && itemDrop) {
        return 0;
    }
    return old_ItemDrop(instance);
}

void (*addScore)(void* instance, int);
void (*subScore)(void* instance, int);

void (*old_PuzzleScene_update)(void* _This, int a2);
void PuzzleScene_update(void* _This, int a2) {
    if (score) {
        switch (scoretype) {
            case 1:
                addScore(_This, scorev);
                break;
            case 2:
                subScore(_This, scorev);
                break;
        }
        score = false; 
    }
    return old_PuzzleScene_update(_This, a2);
}



void (*old_Damage)(void* a1, void* a2, void* a3, float instance, void* a5, void* a6);
void Damage(void* a1, void* a2, void* a3, float instance, void* a5, void* a6) {

    if (onehit) {
        int _damage = 0;

        if (ty == 1) {
            _damage = damage;
        } else if (ty == 2) {
            _damage = damage * bai;
        } else if (ty == 3) {
            _damage = man * 10000;
        }

        instance = _damage;
    }

    // 旧のダメージ関数を呼び出し、その結果を返す
    return old_Damage(a1, a2, a3, instance, a5, a6);
}
void (*Addtime)(void* instance, int);

void (*old_AddTime)(void* _This, int a2);
void AddTime(void* _This, int a2) {
    if (addtime) {
        Addtime(_This, timev);
        addtime = true; 
    }
    return old_AddTime(_This, a2);
}
//================================================================================================================================================

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));
	
	const char *symbol_Scheduler = OBFUSCATE("_ZN3sgf9Scheduler6updateEf");
	const char *symbol_Damage = OBFUSCATE("_ZN23PuzzleEnemyYoukaiSprite17damageToEnemyDataEi");
	const char *symbol_Slow = OBFUSCATE("_ZN7b2World4StepEfiii");
	void* handle = dlopen(targetLibName, RTLD_NOLOAD);

#if defined(__aarch64__)
//================================================================================================================================================
    HOOKSYM_LIB("libSGF.so","_ZN15EnemyYoukaiData15checkDropYoukaiEv", YoukaiDrop,old_YoukaiDrop);//妖怪ドロップ
	HOOKSYM_LIB("libSGF.so","_ZN15EnemyYoukaiData15checkDropYoukaiEv", YoukaiiDrop,old_YoukaiiDrop);//妖怪ドロップ無効
	HOOKSYM_LIB("libSGF.so","_ZN15EnemyYoukaiData13checkDropItemEv", ItemDrop,old_ItemDrop);//アイテムドロップ無効
	HOOKSYM_LIB("libSGF.so","_ZNK3sgf4Mesh9Primitive6renderEv", Keiryou,old_Keiryou);//軽量化
	HOOKSYM_LIB("libSGF.so","_ZN8MapScene15allTouchDisableEv", PostScore,old_PostScore);//郵便スコアタ解放
	HOOKSYM_LIB("libSGF.so","_ZNK21PuzzleTutorialManager15adjustEnemyTimeEf", Enemyturn,old_Enemyturn);//敵ターン固定
	//HOOKSYM_LIB("libSGF.so","_ZN16MapCharactorView9isTouchedEN3sgf4Vec2ES1_NS0_4Mat4E", Talk,old_Talk);//会話無効
	HOOKSYM_LIB("libSGF.so","_ZN23LiveMessageButtonWidget13touchPriorityEi", Jikkyou,old_Jikkyou);//実況無効
	HOOKSYM_LIB("libSGF.so","_ZN7SO_Back9onTouchedERN3sgf2ui14TouchEventArgsE", BackButton,old_BackButton);//戻るボタン無効
	HOOKSYM_LIB("libSGF.so","_ZN8MapScene18openFriendListViewEPK11StageMaster", FriendList,old_FriendList);//フレンドリスト無効
	HOOKSYM_LIB("libSGF.so","_ZN11PuzzleScene17calcDamageToEnemyER23PuzzleEnemyYoukaiSpriteifbb", Damage, old_Damage);//ダメージチョイス
    HOOKSYM_LIB("libSGF.so","_ZNK15MarblesGameData16getFlickingPowerEv", MarbleDamage,old_MarbleDamage);//おはじきダメージ
	HOOKSYM_LIB("libSGF.so","_ZNK15MarblesGameData15calcMarbleSpeedEf", MarbleSpeed, old_MarbleSpeed);//おはじきスピード
 
//================================================================================================================================================
//Speed Cheat
	hexPatches.SpeedReset = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Scheduler) + (uintptr_t) 0x1AC, OBFUSCATE("EBFEFF54"));
	hexPatches.Speed1 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Scheduler) + (uintptr_t) 0x1AC, OBFUSCATE("0028281E"));
	hexPatches.Speed2 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Scheduler) + (uintptr_t) 0x1AC, OBFUSCATE("0010281E"));
	hexPatches.Speed3 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Scheduler) + (uintptr_t) 0x1AC, OBFUSCATE("0090281E"));
	hexPatches.Speed4 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Scheduler) + (uintptr_t) 0x1AC, OBFUSCATE("0050291E"));
	hexPatches.Speed5 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Scheduler) + (uintptr_t) 0x1AC, OBFUSCATE("00702A1E"));
//Damage Cheat
	hexPatches.DamageReset = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Damage) + (uintptr_t) 0xC, OBFUSCATE("F303012A"));
	hexPatches.Damage1 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Damage) + (uintptr_t) 0xC, OBFUSCATE("F3071132"));
	hexPatches.Damage2 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Damage) + (uintptr_t) 0xC, OBFUSCATE("1302A052"));
	hexPatches.Damage3 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Damage) + (uintptr_t) 0xC, OBFUSCATE("130CA052"));
//Slow Cheat
	hexPatches.SlowReset = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Slow) + (uintptr_t) 0x80, OBFUSCATE("0018281E"));
	hexPatches.Slow1 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Slow) + (uintptr_t) 0x80, OBFUSCATE("00702A1E"));
	hexPatches.Slow2 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Slow) + (uintptr_t) 0x80, OBFUSCATE("0050291E"));
	hexPatches.Slow3 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Slow) + (uintptr_t) 0x80, OBFUSCATE("0010281E"));
	hexPatches.Slow4 = MemoryPatch::createWithHex((uintptr_t)dlsym(handle,symbol_Slow) + (uintptr_t) 0x80, OBFUSCATE("000C281E"));
	
	
	addScore = (void(*)(void *,int))getAddressFromSymbol(targetLibName, "_ZN11PuzzleScene8addScoreEm");
    subScore = (void(*)(void *,int))getAddressFromSymbol(targetLibName, "_ZN11PuzzleScene8subScoreEi");
    HOOKSYM_LIB("libSGF.so","_ZN11PuzzleScene6updateEf",PuzzleScene_update,old_PuzzleScene_update);
	
	
	Addtime = (void(*)(void *,int))getAddressFromSymbol(targetLibName, "_ZN20PuzzleScoreAtkSprite7addTimeEi");
    HOOKSYM_LIB("libSGF.so","_ZN20PuzzleScoreAtkSprite6updateEf",AddTime,old_AddTime);

//================================================================================================================================================
#else
    LOGI(OBFUSCATE("Done"));
#endif
    return NULL;
}
    void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;
//================================================================================================================================================
//Speed2
    switch (featNum) {
		case 1://倍速
		   switch (value) {
                case 0:
                    hexPatches.SpeedReset.Modify();
                    break;
                case 1:
                    hexPatches.Speed1.Modify();
                    break;
                case 2:
                    hexPatches.Speed2.Modify();
                    break;
                case 3:
                    hexPatches.Speed3.Modify();
                    break;
                case 4:
                    hexPatches.Speed4.Modify();
                    break;
                case 5:
                    hexPatches.Speed5.Modify();
                    break;
            }
            break;
		case 2://ぷに遅延
		    switch (value) {
                case 0:
                    hexPatches.SlowReset.Modify();
                    break;
                case 1:
                    hexPatches.Slow1.Modify();
                    break;
                case 2:
                    hexPatches.Slow2.Modify();
                    break;
                case 3:
                    hexPatches.Slow3.Modify();
                    break;
				case 4:
                    hexPatches.Slow4.Modify();
                    break;
            }
            break;
		case 3://1.5倍速
            PATCH_SYM_OFFSET_SWITCH("_ZN3sgf9Scheduler6updateEf", 0x1AC ,"0028281E", boolean);
            break;		
	    case 10://わんぱん
			PATCH_SYM_OFFSET_SWITCH("_ZN23PuzzleEnemyYoukaiSprite17damageToEnemyDataEi", 0x20 ,"80000054", boolean);
			PATCH_SYM_OFFSET_SWITCH("_ZN11BossDondoro24getBossTargetPosIdRandomEi", 0x130 ,"E003012A", boolean);
			break;	
		case 11://ダメージ
		    switch (value) {
                case 0:
                    hexPatches.DamageReset.Modify();
                    break;
                case 1:
                    hexPatches.Damage1.Modify();
                    break;
                case 2:
                    hexPatches.Damage2.Modify();
                    break;
                case 3:
                    hexPatches.Damage3.Modify();
                    break;
            }
            break;
		case 20://無敵
            PATCH_SYM_OFFSET_SWITCH("_ZN11PuzzleScene17calcDamageByEnemyEiRK23PuzzleEnemyYoukaiSprite10DamageType", 0x294,"00 08 21 1E", boolean);
			//PATCH_SYM_OFFSET_SWITCH("_ZN23PuzzleEnemyYoukaiSprite6updateEfb", 0xF8,"1F2003D5", boolean);
			break;
	    case 21:
			enemyturn = boolean;
			break;
		case 30://即勝利
            PATCH_SYM_OFFSET_SWITCH("_ZN11PuzzleScene15enemyDeadFinishERKN3sgf2ui9ModelView9EventArgsEb", 0x210 ,"41 01 00 54", boolean);
            break;	
		case 40://軽量化
			//PATCH_SYM_OFFSET_SWITCH("_ZNK3sgf4Mesh9Primitive6renderEv", 0x4 ,"81628052", boolean);
			keiryou = boolean;
            break;	
		case 41://無効化一括
		    PATCH_SYM_OFFSET_SWITCH("_ZN16MapCharactorView9isTouchedEN3sgf4Vec2ES1_NS0_4Mat4E", 0x0,"C0 03 5F D6", boolean);
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI18EnemyInfoWidgetNmlNS_9allocatorIS1_EEED0Ev", 0x98,"C0 03 5F D6", boolean);
			PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI18WinningBonusWidgetNS_9allocatorIS1_EEED0Ev", 0x24BC,"C0 03 5F D6", boolean);
		    jikkyou = boolean;
		    ranking = boolean;
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI28PowerSealedStageDetailWidgetNS_9allocatorIS1_EEED0Ev", 0x98,"C0 03 5F D6", boolean);
		    backButton = boolean;
		    friendList = boolean;
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI12TreasureDataNS_9allocatorIS1_EEED0Ev", 0x43C,"C0 03 5F D6", boolean);
            break;			
		case 42://スコアタ時間停止
            PATCH_SYM_OFFSET_SWITCH("_ZN15CryptoValueBaseIijLj598ELj20768EN22CryptoMonitoringPolicy7DefaultEE6updateEi", 0xD4 ,"20 00 80 52", boolean);
            break;		
		case 50://スコア
            score = true;
            break;
        case 51://スコアValue
            scoretype = value + 1;
            break;
        case 52://スコア指定
            scorev = value;
            break; 
		case 53:
            onehit = boolean;
            break;
        case 54:
            ty = value + 1;
            break;
        case 55:
            damage = value;
            break;
        case 56:
            bai = value;
            break;
        case 57:
            man = value;
            break;  
		case 58:
			timev = value;
		case 59:
			addtime = boolean;
			break;
		case 60:
			damagevalue = value;
			break;
		case 61:
			marbledamage = boolean;
			break;
		case 63:
			marblespeed = boolean;
			break;	
		case 70:
			youkaiDrop = boolean;
			break;
		case 80:
			youkaiiDrop = boolean;
			break;	
		case 90:
			itemDrop = boolean;
			break;	
		case 91://鍵泥無効
            PATCH_SYM_OFFSET_SWITCH("_ZNK15ProtocolGameEnd17EnemyYoukaiResult10doParamSetERN11HttpRequest9ParameterE", 0x3e0 ,"E2 03 1F 2A", boolean);
            break;		
		case 1000://即技
		    PATCH_SYM_OFFSET_SWITCH("_Z12safeStrToNumRKNSt6__ndk112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEEi", 0xD4,"E1 03 26 1E", boolean);
            break;
		case 1010://即フィーバー
		    PATCH_SYM_OFFSET_SWITCH("_ZN21PuzzleTutorialManager12checkClearedEv", 0x7C,"3F 05 00 71", boolean);
            break;	
		case 1020://無限フィーバー
		    PATCH_SYM_OFFSET_SWITCH("_ZN21PuzzleTutorialManager12checkClearedEv", 0xB8,"3F 05 00 71", boolean);
            break;	
		case 1030://ボナ玉生成
		    PATCH_SYM_OFFSET_SWITCH("_ZNK17BonusBlockManager13lotBonusBlockEi", 0x88,"1F 01 0D 6B", boolean);
            break;	
		case 1040://全ぷに繋がる
		    PATCH_SYM_OFFSET_SWITCH("_ZN14PuzzleAreaImpl12onTouchMovedERKN3sgf4Vec2E", 0x170,"80 FC 07 37", boolean);
			PATCH_SYM_OFFSET_SWITCH("_ZN14PuzzleAreaImpl12onTouchMovedERKN3sgf4Vec2E", 0x17C,"1F 20 03 D5", boolean);
            break;	
		case 1050://でかぷに
		    PATCH_SYM_OFFSET_SWITCH("_ZN14PuzzleAreaImpl11makeNewPuyoEf", 0x5C4,"9C 00 80 52", boolean);
            break;	
		case 1060://ぷに1色
		    PATCH_SYM_OFFSET_SWITCH("_ZN14PuzzleAreaImpl7addPuyoEiibRKN3sgf4Vec2EbfN4puyo8PuyoTypeENSt6__ndk112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEibPK16BonusBlockMasterf", 0x64,"FB 03 1F 2A", boolean);
            break;	
		case 1999://無効化一括
		    PATCH_SYM_OFFSET_SWITCH("_ZN16MapCharactorView9isTouchedEN3sgf4Vec2ES1_NS0_4Mat4E", 0x0,"C0 03 5F D6", boolean);
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI18EnemyInfoWidgetNmlNS_9allocatorIS1_EEED0Ev", 0x98,"C0 03 5F D6", boolean);
			PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI18WinningBonusWidgetNS_9allocatorIS1_EEED0Ev", 0x24BC,"C0 03 5F D6", boolean);
		    jikkyou = boolean;
		    ranking = boolean;
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI28PowerSealedStageDetailWidgetNS_9allocatorIS1_EEED0Ev", 0x98,"C0 03 5F D6", boolean);
		    backButton = boolean;
		    friendList = boolean;
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI12TreasureDataNS_9allocatorIS1_EEED0Ev", 0x43C,"C0 03 5F D6", boolean);
            break;		
		case 2000://会話無効化
		    PATCH_SYM_OFFSET_SWITCH("_ZN16MapCharactorView9isTouchedEN3sgf4Vec2ES1_NS0_4Mat4E", 0x0,"C0 03 5F D6", boolean);
            break;
		case 2010://虫眼鏡無効化
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI18EnemyInfoWidgetNmlNS_9allocatorIS1_EEED0Ev", 0x98,"C0 03 5F D6", boolean);
			PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI18WinningBonusWidgetNS_9allocatorIS1_EEED0Ev", 0x24BC,"C0 03 5F D6", boolean);
            break;	
		case 2020:
		    jikkyou = boolean;
			break;	
		case 2030:
		    ranking = boolean;
			break;	
		case 2040://封印無効化
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI28PowerSealedStageDetailWidgetNS_9allocatorIS1_EEED0Ev", 0x98,"C0 03 5F D6", boolean);
            break;
		case 2060:
		    backButton = boolean;
			break;
		case 2070:
		    friendList = boolean;
			break;	
		case 2080://横取り無効化
		    PATCH_SYM_OFFSET_SWITCH("_ZNSt6__ndk120__shared_ptr_emplaceI12TreasureDataNS_9allocatorIS1_EEED0Ev", 0x43C,"C0 03 5F D6", boolean);
            break;	
		case 2090://ダイアログ
	        PATCH_SYM_OFFSET_SWITCH("_ZN10MapProcess28ChkTreasureCollectionProcess8onAttachEv", 0x40,"1F 09 40 B9 21 03 00 35", boolean);
            break;
		case 2100://お知らせダイアログ
		    PATCH_SYM_OFFSET_SWITCH("_ZN10MapProcess20ChkShowNoticeProcess8onAttachEv", 0x34,"3F 05 40 38 3F 02 00 34", boolean);
            break;	
		case 2110://スコアタダイアログ
		    PATCH_SYM_OFFSET_SWITCH("_ZN10MapProcess21ChkShowRankingProcess8onAttachEv", 0x2C,"1F D0 44 39 28 03 00 35", boolean);
            break;
		case 2120://ログボダイアログ
		    PATCH_SYM_OFFSET_SWITCH("_ZN10MapProcess28ChkLoginStampViewOpenProcess8onAttachEv", 0x2C,"3F 05 40 38 68 07 00 35", boolean);
            break;	
		case 2130://人魂演出
		    PATCH_SYM_OFFSET_SWITCH("_ZN18EventMapDetailShowD0Ev", 0x8A0,"08 01 1F 2B", boolean);
            break;	
		case 2140://フィニッシュ演出
		    PATCH_SYM_OFFSET_SWITCH("_ZN11PuzzleScene17damageToEnemyDataEP14UserYoukaiDataibR23PuzzleEnemyYoukaiSpriteii", 0x300,"1F 04 00 31", boolean);
            break;	
		case 2150://倒れる演出
		    PATCH_SYM_OFFSET_SWITCH("_ZN3sgf2ui9ModelView10playOnOnceEiNSt6__ndk18functionIFvRKNS1_9EventArgsEEEE", 0x2C,"F4 03 0A 2A", boolean);
            break;		
		case 2160://レベルアップスキップ
		    PATCH_SYM_OFFSET_SWITCH("_ZN12ResultStatus16startUpdateGaugeEv", 0x2C,"C8 01 00 35", boolean);
            break;	
		case 2170://リザルトスキップ
		    PATCH_SYM_OFFSET_SWITCH("_ZN11PuzzleScene12onTouchEndedERN3sgf2ui14TouchEventArgsE", 0x204,"1F 04 00 71", boolean);
            break;	
		case 3000://全開放
			PATCH_SYM_OFFSET_SWITCH("_ZN11EventButton10initializeEPK11EventMasterb", 0xCC,"E1 03 1F 2A", boolean);
			postscore = boolean;
			break;	
		case 3010:
		    PATCH_SWITCH("0x3fcbd98", "C0 03 5F D6", boolean);       
            break;		  
    }
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}
#include "Register.h"
