jobjectArray GetModList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
		    OBFUSCATE("Category_メイン"),
            OBFUSCATE("1_SeekBar_倍速_0_5"),
			OBFUSCATE("2_SeekBar_ぷに遅延_0_4"),
			OBFUSCATE("3_Toggle_1.5倍速"),
            OBFUSCATE("10_Toggle_わんぷにワンパン"),
            OBFUSCATE("11_Selecttf_高ダメージ_OFF,9万,100万"),
			OBFUSCATE("SetHori_ "),
            OBFUSCATE("20_HoriAdd_CheckBox_無敵　　　　"),
			OBFUSCATE("21_HoriAdd_CheckBox_敵ターン固定"),
			OBFUSCATE("SetHori_ "),
			OBFUSCATE("30_HoriAdd_CheckBox_即勝利　　　"),
			OBFUSCATE("40_HoriAdd_CheckBox_軽量化"),
			OBFUSCATE("41_Toggle_無効化一括"),
			OBFUSCATE("42_Toggle_スコアタ時間停止"),
			//OBFUSCATE("Collapse_Hook"),
			OBFUSCATE("50_Button_スコア"),
			OBFUSCATE("51_Selecttf_s_増やす,減らす"),
            //OBFUSCATE("51_CollapseAdd_Spinner_s_増やす,減らす"),
            OBFUSCATE("52_InputValue_ "),
			OBFUSCATE("0_Category_Damage"),
			OBFUSCATE("53_Toggle_ダメージ"),
			OBFUSCATE("54_Selecttf_Damage_指定,〇倍,〇万"),
            //OBFUSCATE("54_CollapseAdd_Spinner_あ_ダメージ指定,〇倍,〇万"),
            OBFUSCATE("55_InputValue_ダメージ"),
            OBFUSCATE("56_SeekBar_〇倍_1_5"),
            OBFUSCATE("57_SeekBar_〇万_1_200"),  
			//OBFUSCATE("58_CollapseAdd_InputValue_スコアタ時間"),
			//OBFUSCATE("59_CollapseAdd_Button_増加"),
			//OBFUSCATE("CollapseAdd_Category_おはごる系"),
			//OBFUSCATE("60_CollapseAdd_InputValue_おはごるダメージ"),
			//OBFUSCATE("61_CollapseAdd_Toggle_設定"),
			OBFUSCATE("63_Toggle_おはごるスピードUp"),
			OBFUSCATE("64_Toggle_おはごる邪魔玉無効"),
			OBFUSCATE("64_Toggle_おはごる確定P"),
			OBFUSCATE("54_Selecttf_Golfturn変更_OFF,1,2,3,4,5"),
			OBFUSCATE("54_Selecttf_Golfturn変更_OFF,-1,-2,-3,-4,-5"),
			//OBFUSCATE("0_CollapseAdd_Selecttf_おはゴルターン_OFF,3ターンジャンプ,-2ターンジャンプ"),
			//OBFUSCATE("0_CollapseAdd_Spinner_おはごるターン_OFF,3ターンジャンプ,-2ターンジャンプ"),
			
			OBFUSCATE("Collapse_ドロップチート"),
	        OBFUSCATE("70_CollapseAdd_Toggle_確泥"),
	        OBFUSCATE("80_CollapseAdd_Toggle_確泥無効"),
			OBFUSCATE("90_CollapseAdd_Toggle_アイテム泥無効"),
			OBFUSCATE("91_CollapseAdd_Toggle_鍵泥無効"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetSubList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_パズル"),
            OBFUSCATE("1000_Toggle_即技"),
            OBFUSCATE("1010_Toggle_即フィーバー"),
            OBFUSCATE("1020_Toggle_無限フィーバー"),
			OBFUSCATE("1030_Toggle_ボナ玉生成"),
            OBFUSCATE("1040_Toggle_全ぷに繋がる"),
			OBFUSCATE("1050_Toggle_でかぷに"),
            OBFUSCATE("1060_Toggle_ぷに1色"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    settingsValid = true;

    return (ret);
}

jobjectArray GetLibList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_効率化"),
            OBFUSCATE("Collapse_無効化"),
			OBFUSCATE("1999_CollapseAdd_CheckBox_無効化一括"),
			OBFUSCATE("2000_CollapseAdd_Toggle_マップ会話無効"),
		    OBFUSCATE("2010_CollapseAdd_Toggle_虫眼鏡無効"),
			OBFUSCATE("2020_CollapseAdd_Toggle_実況無効"),
		    OBFUSCATE("2030_CollapseAdd_Toggle_ランキング無効"),
            OBFUSCATE("2040_CollapseAdd_Toggle_封印無効"),
            OBFUSCATE("2050_CollapseAdd_Toggle_BOX無効"),
			OBFUSCATE("2060_CollapseAdd_Toggle_戻るボタン無効"),
		    OBFUSCATE("2070_CollapseAdd_Toggle_フレアイコン無効"),
			OBFUSCATE("2080_CollapseAdd_Toggle_横取り無効"),
			
			OBFUSCATE("Collapse_ダイアログ無効化"),
			//OBFUSCATE("2089_CollapseAdd_CheckBox_ダイアログ無効化一括"),
			OBFUSCATE("2090_CollapseAdd_Toggle_お宝ダイアログ無効化"),
		    OBFUSCATE("2100_CollapseAdd_Toggle_お知らせダイアログ無効"),
			OBFUSCATE("2110_CollapseAdd_Toggle_スコアタダイアログ無効化"),
			OBFUSCATE("2120_CollapseAdd_Toggle_ログボダイアログ無効化"),
			
		    OBFUSCATE("Collapse_演出短縮"),
			OBFUSCATE("2130_CollapseAdd_Toggle_人魂演出短縮"),
		    OBFUSCATE("2140_CollapseAdd_Toggle_フィニッシュ演出無効化"),
			OBFUSCATE("2150_CollapseAdd_Toggle_倒れる演出短縮"),
			
			OBFUSCATE("2160_Toggle_レベルアップスキップ"),
            OBFUSCATE("2170_Toggle_リザルトスキップ"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    settingsValid = true;

    return (ret);
}

jobjectArray GetLinkList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_その他"),
            OBFUSCATE("3000_Toggle_True_郵便スコアタイベ解放"),
            OBFUSCATE("3010_Toggle_アカウント削除"),
			OBFUSCATE("Collapse_アカウント設定"),
            OBFUSCATE("CollapseAdd_LogOut_ログアウト"),
			OBFUSCATE("3030_EndApp_アプリ終了"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    settingsValid = true;

    return (ret);
}

jobjectArray SelectedList(JNIEnv *env, jobject context) {
	jobjectArray ret;
	
	const char *features[] = {
		OBFUSCATE("-100_Button_メイン"),
		OBFUSCATE("-99_Button_パズル"),
		OBFUSCATE("-98_Button_効率化"),
		OBFUSCATE("-97_Button_その他"),
		};
		
	int Total_Feature = (sizeof features / sizeof features[0]);
	ret = (jobjectArray)
	    env->NewObjectArray(Total_Feature, env->FindClass(("java/lang/String")),
                                env->NewStringUTF(""));

	for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
		
		settingsValid = true;
		
		return (ret);
}


