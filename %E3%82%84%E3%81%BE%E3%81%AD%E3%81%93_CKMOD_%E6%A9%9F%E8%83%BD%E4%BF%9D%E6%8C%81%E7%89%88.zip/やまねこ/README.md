# やまねこ CKMODテンプレート

CKMODのAndroidソースプロジェクトです。表示名は「やまねこ」に設定されています。

- `app/src/main/res/values/strings.xml` — アプリ表示名
- `app/src/main/java/com/android/support/Menu.java` — フローティングメニューUI
- `app/src/main/jni/Function/Function.h` — メニュー項目
- `app/src/main/jni/Main.cpp` — ネイティブ処理
- `app/build.gradle` — Androidビルド設定

移植内容と未検証事項は [`移植状況_日本語.md`](移植状況_日本語.md) を確認してください。

このプロジェクトはソース一式であり、APK完成品ではありません。Android SDK/NDK等が必要です。
